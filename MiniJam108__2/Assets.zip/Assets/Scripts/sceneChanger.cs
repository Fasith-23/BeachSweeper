using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class sceneChanger : MonoBehaviour
{   
    public Vector2 playerPos= new Vector2 (5,5);
    public Rigidbody RB;
    public Text posText;
    public MineField minefield;
    Vector2 N= new Vector2(0,1);
    Vector2 E= new Vector2(1,0);
    // Start is called before the first frame update
    void Start()
    {
        posText.text = "(" + playerPos.x.ToString() + "," + playerPos.y.ToString() + ")\n Nearby Mines:" + minefield.mineCount[(int)playerPos.x,(int)playerPos.y];
    }

    // Update is called once per frame
    void Update()
    {
        playerPos= new Vector2((int)(RB.position.x/10),(int)(RB.position.z/10));
        posText.text = "(" + playerPos.x.ToString() + "," + playerPos.y.ToString() + ")\n Nearby Mines:" + minefield.mineCount[(int)playerPos.x,(int)playerPos.y];
    }
    void Transition(Vector2 Trans){
        playerPos = playerPos + Trans;
    }
    void OnTriggerEnter(Collider other){
        if(other.gameObject.name == "NE"){
            playerPos = playerPos + N + E;
        }
        if(other.gameObject.name == "N"){
            playerPos = playerPos + N;
        }
        if(other.gameObject.name == "SE"){
            playerPos = playerPos + E - N;
        }
        if(other.gameObject.name == "S"){
            playerPos = playerPos - N;
        }
        if(other.gameObject.name == "E"){
            playerPos = playerPos + E;
        }
        if(other.gameObject.name == "W"){
            playerPos = playerPos - E;
        }
        if(other.gameObject.name == "SW"){
            playerPos = playerPos - N - E;
        }
        if(other.gameObject.name == "NW"){
            playerPos = playerPos - E + N;
        }
        posText.text = "(" + playerPos.x.ToString() + "," + playerPos.y.ToString() + ")\n Nearby Mines:" + minefield.mineCount[(int)playerPos.x,(int)playerPos.y];
    }
}
